<?php 
//session test
require 'check_admin.php';


//conection with database
require '../connection/conn.php';
//check if data recived or no 
if (!empty($_POST['money'])) {
	$money = $_POST['money'];
	if (!empty($_POST['sponser_name'])) {
		$sponser_name = $_POST['sponser_name'];
		if (!empty($_POST['mobile'])) {
			$mobile = $_POST['mobile'];
			if (!empty($_POST['email'])) {
				$email = $_POST['email'];
				$type = $_POST['type'];
				if (filter_var($email , FILTER_VALIDATE_EMAIL)) {
					$query = mysqli_query($connect , "INSERT INTO sponsor VALUES ('' , '$sponser_name' , 
						'$money' , '$mobile' , '$email' , '$type') ");
					if ($query) {
						header("location: sponsers.php?msg=inserted");die();
					}
					header("location: add_sponser.php?msg=error");die();
					
				}
				else
				{
					header("location: add_sponser.php?msg=error_email");die();

				}
			}
			else
			{
				header("location: add_sponser.php?msg=empty_data");die();

			}
		}
		else
		{
			header("location: add_sponser.php?msg=empty_data");die();

		}

		
	}
	else
	{
		header("location: add_sponser.php?msg=empty_data");die();

	}

}
else
{
	header("location: add_sponser.php?msg=empty_data");die();
}







?>