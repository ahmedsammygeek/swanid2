
<?php 

require 'header.php';
 ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header text-right">لوحة التحكم</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <img src="../images/11241141_460814440740377_1143352320_o.jpg" width="100%" height="100%" alt="">
             

                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->



    <?php 
    require 'footer.php';

     ?>