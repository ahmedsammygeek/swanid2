<?php 
//session test
require 'check_admin.php';
//get id from link
if (isset($_GET['id'])) {
	$id=$_GET['id'];
}
//conection with database
require '../connection/conn.php';
//check if data recived or no 
if (!empty($_POST['money'])) {
	$money = $_POST['money'];
	if (!empty($_POST['sponser_name'])) {
		$sponser_name = $_POST['sponser_name'];
		if (!empty($_POST['mobile'])) {
			$mobile = $_POST['mobile'];
			if (!empty($_POST['email'])) {
				$email = $_POST['email'];
				if (filter_var($email , FILTER_VALIDATE_EMAIL)) {
					$query = mysqli_query($connect , "UPDATE sponsor SET `money`='$money',sponsor_name='$sponser_name',mobile='$mobile',email='$email' WHERE id = '$id'  ");
					if ($query) {
						header("location: sponsers.php?msg=updated");die();
					}
					header("location: edit_sponser.php?msg=error&id=$id");die();
					
				}
				else
				{
					header("location: edit_sponser.php?msg=error_email&id=$id");die();

				}
			}
			else
			{
				header("location: edit_sponser.php?msg=empty_data&id=$id");die();

			}
		}
		else
		{
			header("location: edit_sponser.php?msg=empty_data&id=$id");die();

		}

		
	}
	else
	{
		header("location: edit_sponser.php?msg=empty_data&id=$id");die();

	}

}
else
{
	header("location: edit_sponser.php?msg=empty_data&id=$id");die();
}







?>