
<?php 

require 'header.php';
?>
<div id="page-wrapper">
  <div class="row">
    <div class="col-lg-12">
      <h1 class="page-header">طلبات الالتحاق</h1>
    </div>
    <!-- /.col-lg-12 -->
  </div>
  <!-- /.row -->
  <div class="row">

    <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <!-- <p class="fa text-right">طلبات الالتحاق</p>  -->
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group">
                                <a href="event_applicants.php" class="list-group-item">
                                    <p class="text-right"> طلبات التحاق بمناسبة</p>
                                    
                                    
                                </a>
                                <a href="track_applicants.php" class="list-group-item">
                                     <p class="text-right">طلبات التحاق بمسار</p>
                                    
                                   
                                </a>
                                <a href="gallery_applicants.php" class="list-group-item">
                                    <p class="text-right">طلبات التحاق بمعرض</p> 
                                    
                                    
                                </a>
                                <a href="career_applicants.php" class="list-group-item">
                                   <p class="text-right">طلبات التحاق بوظيفة</p> 
                                   
                                   
                                </a>
                            </div>
                            <!-- /.list-group -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                
                 
                    <!-- /.panel .chat-panel -->
                </div>
    <!-- /.col-lg-4 -->
  </div>
  <!-- /.row -->
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->




<?php 
require 'footer.php';

?>

